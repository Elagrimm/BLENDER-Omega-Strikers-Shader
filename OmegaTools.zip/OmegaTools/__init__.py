import bpy

from bpy.props import PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup


bl_info = {
    "name": "OmegaTools",
    "author": "",
    "version": (0, 0, 0),
    "blender": (4, 1, 0),
    "location": "Node Editor > Node",
    "description": "",
    "doc_url": "",
    "tracker_url": "",
    "category": "Node", # 3D View
}

########################### Custom Variables

# scene.omega_variables

class OMEGA_variables(PropertyGroup):
    armature_obj: PointerProperty(name='Armature', type=bpy.types.Object)
    target_bone: StringProperty(name='Bone', default='head_JNT')

########################### Omega Tools


def find_node_label(node_label, start_tree):
    for node in start_tree.nodes:
        if node.type != 'FRAME' and node.label == node_label:
            return node

        if hasattr(node, 'node_tree'):
            if (node := find_node_label(node_label, node.node_tree)):
                return node

    return None

class OMEGA_OT_assign_glasses_drivers(Operator):
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}

    bl_idname = 'omega.assign_glasses_drivers'
    bl_label = 'Assign Drivers'
    bl_description = 'Assign bone drivers to the active material'

    @classmethod
    def poll(cls, context):
        vars = context.scene.omega_variables
        return vars.armature_obj and vars.armature_obj.type == 'ARMATURE'

    def execute(self, context):

        vars = context.scene.omega_variables

        tree = context.space_data.node_tree

        # TODO: Do not go through all the nodes twice.
        node_pos = find_node_label('HeadPosition', tree)
        node_rot = find_node_label('HeadRotation', tree)

        if node_pos is None or node_rot is None:
            self.report({'WARNING'}, f'"HeadPosition" or "HeadRotation" node labels were not found.')

        if node_pos.type != 'COMBXYZ' or node_rot.type != 'COMBXYZ':
            self.report({'WARNING'}, f'"{node_pos.label}" or "{node_pos.label}" types are not "Combine XYZ".')

        # Update the values (position).
        for index, input in enumerate(node_pos.inputs):
            ttype = ('LOC_X', 'LOC_Y', 'LOC_Z')

            driver = input.driver_add('default_value').driver # .driver_remove()?
            driver_var = driver.variables.new() if len(driver.variables) < 1 else driver.variables[0] # Assume to always use the first variable.

            driver.type = 'SCRIPTED'
            driver.expression = driver_var.name

            driver_var.type = 'TRANSFORMS'
            driver_var.targets[0].id = vars.armature_obj
            driver_var.targets[0].bone_target = vars.target_bone
            driver_var.targets[0].transform_type = ttype[index] # LOC_X;ROT_X;SCALE_X;SCALE_AVG
            driver_var.targets[0].transform_space = 'WORLD_SPACE' # WORLD_SPACE;TRANSFORM_SPACE;LOCAL_SPACE

        # Update the values (rotation).
        for index, input in enumerate(node_rot.inputs):
            ttype = ('ROT_X', 'ROT_Y', 'ROT_Z')

            driver = input.driver_add('default_value').driver
            driver_var = driver.variables.new() if len(driver.variables) < 1 else driver.variables[0]

            driver.type = 'SCRIPTED'
            driver.expression = driver_var.name

            driver_var.type = 'TRANSFORMS'
            driver_var.targets[0].id = vars.armature_obj
            driver_var.targets[0].bone_target = vars.target_bone
            driver_var.targets[0].transform_type = ttype[index]
            driver_var.targets[0].transform_space = 'WORLD_SPACE'

        self.report({'INFO'}, 'Successfully updated the drivers.')

        return {'FINISHED'}


class OMEGA_PT_omega_node_tools(Panel):
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Node'

    bl_idname = 'OMEGA_PT_omega_node_tools'
    bl_label = 'Omega Tools'

    def draw(self, context):
        layout = self.layout
        vars = context.scene.omega_variables

        col = layout.column(align=True)
        col.prop(vars, 'armature_obj')

        if vars.armature_obj:
            col.prop_search(vars, 'target_bone', vars.armature_obj.data, 'bones')
        else:
            col.label(text='Bone:')

        layout.operator('omega.assign_glasses_drivers', icon='DRIVER')

#===========================

classes = [
    OMEGA_variables,

    # Omega Tools
    OMEGA_OT_assign_glasses_drivers,
    OMEGA_PT_omega_node_tools,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.omega_variables = PointerProperty(type=OMEGA_variables)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

    del bpy.types.Scene.omega_variables

if __name__ == "__main__": # debug; live edit
    register()
